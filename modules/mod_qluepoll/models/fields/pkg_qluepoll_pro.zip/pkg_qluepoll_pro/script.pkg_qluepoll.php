<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  mod_qluetwitter
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted Access');

class mod_qlueweatherInstallerScript {

function postflight($type, $parent) {
?>
<div style="text-align:left; margin:auto" class="row">
    <div class="span4">
        <img style="" src="https://qlue.uk/images/extensions/weather.jpg"></img>
    </div>
    <div class="span5 well">
        <h1>Thanks for installing Qlue Weather Pro!</h1>
        <p>This module can display current, furture and past weather, using the Open Weather API. 
        <!-- For a quick start guide <a>click here</a>, or follow <a>this link</a> for full documentation.</p> -->
        </p>
        <h3>Features</h3>
        <ul>
            <span class="qlue-listitem qlue-feature">Presets and custom styles</span>
            <span class="qlue-listitem qlue-feature">Display the current weather or a slider of future/historical weather</span>
            <span class="qlue-listitem qlue-feature">Customise each display type</span>
            <span class="qlue-listitem qlue-feature">Change units on back or front end</span>
            <span class="qlue-listitem qlue-feature">Show or hide various weather stats</span>
        </ul>
        <h3>Changelog <small style="color:black;">V2.0.0</small></h3>
        <ul>
            <span class="qlue-listitem"><span class="badge badge-success">Added</span> slider customisation.</span>
            <span class="qlue-listitem"><span class="badge badge-success">Added</span> additional data.</span>
            <span class="qlue-listitem"><span class="badge badge-success">Added</span> ability to show/hide all data options.</span>
            <span class="qlue-listitem"><span class="badge badge-success">Added</span> temprature graph.</span>
            <span class="qlue-listitem"><span class="badge badge-success">Added</span> ability to customise module styles.</span>
            <span class="qlue-listitem"><span class="badge badge-warning">Fixed</span> issue with having multiple qlue weather modules on the same page.</span>
        </ul>
    </div>
<div>

<style>
    /* span {
        display: block;
    } */

    .qlue-listitem {
        margin-bottom: 5px;
        display: block;
    }

    .qlue-feature {
        margin-left: 25px;
    }

    img {
        margin-bottom: 5px;
    }
</style>
<?php 
    }
} 
?>