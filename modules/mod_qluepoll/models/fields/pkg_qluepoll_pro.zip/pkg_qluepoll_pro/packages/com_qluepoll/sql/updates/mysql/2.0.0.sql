ALTER TABLE `#__qluepoll_votes` ADD `user_id` INT;
ALTER TABLE `#__qluepoll_votes` ADD `voted_at` TIMESTAMP;
