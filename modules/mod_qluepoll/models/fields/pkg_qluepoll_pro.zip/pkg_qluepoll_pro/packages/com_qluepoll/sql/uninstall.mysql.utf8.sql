DROP TABLE IF EXISTS `#__qluepoll`;
DROP TABLE IF EXISTS `#__qluepoll_awnsers`;
DROP TABLE IF EXISTS `#__qluepoll_votes`;